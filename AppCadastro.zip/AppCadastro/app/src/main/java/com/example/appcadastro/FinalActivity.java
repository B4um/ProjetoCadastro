package com.example.appcadastro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FinalActivity extends AppCompatActivity {

    Button btnExcluir;
    private SQLiteDatabase bancoDados;
    Intent intent;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        intent = getIntent();
        email = intent.getStringExtra("email");

        btnExcluir = (Button) findViewById(R.id.btnExcluir);

        carregarDados();

        btnExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                excluirConta();
            }
        });
    }

    public void excluirConta(){
        try{
            bancoDados = openOrCreateDatabase("cadastro", MODE_PRIVATE, null);
            String sql = "DELETE FROM usuario WHERE email = ?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.bindString(1,email);
            stmt.executeUpdateDelete();
            bancoDados.close();
            abrirTelaPrincipal();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void carregarDados(){
        try {
            bancoDados = openOrCreateDatabase("cadastro", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT * FROM usuario WHERE email = '" + email + "'", null);
            cursor.moveToFirst();

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void abrirTelaPrincipal(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}